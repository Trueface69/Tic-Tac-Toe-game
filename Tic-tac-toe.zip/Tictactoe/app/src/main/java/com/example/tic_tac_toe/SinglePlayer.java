package com.example.tic_tac_toe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class SinglePlayer extends AppCompatActivity {
    ArrayList player1,player2,emptyCells;
    boolean gameOver=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gameactivity);
        Intent intent1=getIntent();
        Toast.makeText(this, "you have selected Single player", Toast.LENGTH_LONG).show();
    }
    public void buClick(View view) {
        Button buSelected = (Button) view;
        int cellID = 0;

        switch (buSelected.getId()) {
            case R.id.bu1:
                cellID = 1;
                break;
            case R.id.bu2:
                cellID = 2;
                break;
            case R.id.bu3:
                cellID = 3;
                break;
            case R.id.bu4:
                cellID = 4;
                break;
            case R.id.bu5:
                cellID = 5;
                break;
            case R.id.bu6:
                cellID = 6;
                break;
            case R.id.bu7:
                cellID = 7;
                break;
            case R.id.bu8:
                cellID = 8;
                break;
            case R.id.bu9:
                cellID = 9;
                break;
            default:
                break;
        }
        playGame(cellID, buSelected);
    }

    public void playGame(int CellID, Button buSelected) {

        while (!gameOver){
            int activePlayer = 1;
            {

                if (activePlayer == 1) {
                    buSelected.setBackgroundColor(Color.RED);
                    player1.add(CellID);
                    activePlayer = 2;
                    autoPlay();

                } else if (activePlayer == 2) {
                    buSelected.setBackgroundColor(Color.GREEN);
                    player2.add(CellID);
                    activePlayer = 1;
                }
            }
        }
        buSelected.setEnabled(false);
        checkWinner();
    }

    public void checkWinner() {
        int winner = -1;
//        player1 rules to win the game

        if (player1.contains(1) && player1.contains(2) && player1.contains(3) || player1.contains(1)&& player1.contains(4)&&player1.contains(7)
                || player1.contains(4) && player1.contains(5) && player1.contains(6) || player1.contains(2)&& player1.contains(5)&&player1.contains(8)
                || player1.contains(7) && player1.contains(8) && player1.contains(9) || player1.contains(3)&& player1.contains(6)&&player1.contains(9)
                || player1.contains(1) && player1.contains(5) && player1.contains(9) || player1.contains(3) && player1.contains(5) && player1.contains(7)) {
            winner = 1;

        }
//        player2 rules to win the game
        else if (player2.contains(1) && player2.contains(2) && player2.contains(3) || player2.contains(1)&& player2.contains(4)&&player2.contains(7)
                || player2.contains(4) && player2.contains(5) && player2.contains(6) || player2.contains(2)&& player2.contains(5)&&player2.contains(8)
                || player2.contains(7) && player2.contains(8) && player2.contains(9) || player2.contains(3)&& player2.contains(6)&&player2.contains(9)
                || player2.contains(1) && player2.contains(5) && player2.contains(9) || player2.contains(3) && player2.contains(5) && player2.contains(7)) {
            winner = 2;
        }

        if (winner!=-1){
            if (winner==1){
                Toast.makeText(this, "Hurray Player 1 Has Won", Toast.LENGTH_SHORT).show();
                gameOver=true;
            }

            else if (winner==2){
                Toast.makeText(this, "Hurray Player 2 Has Won", Toast.LENGTH_SHORT).show();
                gameOver=true;
            }
        }
    }

    public void autoPlay(){
        for(int cell=0;cell<10;cell++){
            if (!(player1.contains(cell)||player2.contains(cell))){
                emptyCells.add(cell);
            }
        }
        Random r=new Random();
        int randIndex=r.nextInt(emptyCells.size()-0)+0;
        int cellID= (int) emptyCells.get(randIndex);

        Button buSelected = null;
        switch (cellID) {
            case 1:
                buSelected=findViewById(R.id.bu1);
                break;
            case 2:
                buSelected=findViewById(R.id.bu2);
                break;
            case 3:
                buSelected=findViewById(R.id.bu3);
                break;
            case 4:
                buSelected=findViewById(R.id.bu4);
                break;
            case 5:
                buSelected=findViewById(R.id.bu5);
                break;
            case 6:
                buSelected=findViewById(R.id.bu6);
                break;
            case 7:
                buSelected=findViewById(R.id.bu7);
                break;
            case 8:
                buSelected=findViewById(R.id.bu8);
                break;
            case 9:
                buSelected=findViewById(R.id.bu9);
                break;
            default:
                break;
        }
        playGame(cellID, buSelected);
    }
}