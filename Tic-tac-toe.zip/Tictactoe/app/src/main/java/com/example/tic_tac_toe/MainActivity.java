package com.example.tic_tac_toe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Spinner playingOptions;
    Button button;
    TextView textView;
    EditText editText;
    Intent intent1,intent2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        playingOptions = findViewById(R.id.playingOptions);
        button = findViewById(R.id.nameBtn);
        button = findViewById(R.id.singlePBtn);
        button = findViewById(R.id.multiPBtn);
        editText = findViewById(R.id.editTextPersonName);
        textView = findViewById(R.id.txtView2);

        textView.setVisibility(TextView.INVISIBLE);


//              adding items to my spinner
//        final ArrayList<String> pOptions = new ArrayList<>();
//        pOptions.add("   ");
//        pOptions.add("Easy");
//        pOptions.add("Hard");
//        pOptions.add("Pro");
//
////        my spinner adapter
//        ArrayAdapter<String> pOAdapter = new ArrayAdapter<>(
//                this,
//                android.R.layout.simple_spinner_dropdown_item,
//                pOptions);
//        playingOptions.setAdapter(pOAdapter);

        playingOptions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(MainActivity.this, "Level " + pOptions.get(position)+" Selected", Toast.LENGTH_SHORT).show();
                Toast.makeText(MainActivity.this, "level "+playingOptions.getSelectedItem().toString()+" Selected", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mainmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.settings:
                Toast.makeText(this, "settings", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.exit:
                finish();
                System.exit(0);
        }
        return super.onOptionsItemSelected(item);
    }

    public void onBtnClick(View view) {
        switch (view.getId()) {
            case R.id.nameBtn:
                if (editText.getText().toString().equals("")) {
                    Toast.makeText(this, "Enter a valid name", Toast.LENGTH_SHORT).show();
//                    TODO
//                     disable edit text
//                     fix null entry toast

                } else {
                    textView.setText(editText.getText().toString()+"Hi ");
                    textView.setVisibility(TextView.VISIBLE);
                    textView.setTextColor(Color.BLACK);
                }
                break;
            case R.id.singlePBtn:
                Intent intent1 = new Intent(MainActivity.this, SinglePlayer.class);
                startActivity(intent1);

                break;
            case R.id.multiPBtn:
                Intent intent2 = new Intent(MainActivity.this, MultiPlayer.class);
                startActivity(intent2);
                break;
        }

    }

}